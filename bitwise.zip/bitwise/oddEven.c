//Write a C program to check whether a given number is even or odd using a bitwise operator.


 #include <stdio.h>

int main()
{
    int n;

    scanf("%d", &n);

    // The last bit is 0 for even numbers
    if ((n & 1) == 0)
        printf("Even");
    else
        printf("Odd");

    return 0;
}