#include <stdio.h>

int main() {
    int a = 60;  // Binary: 00111100
    int b = 13;  // Binary: 00001101

    // Bitwise AND (&)
    // A bit is 1 only when both corresponding bits are 1.
    printf("a & b = %d\n", a & b);

    // Bitwise OR (|)
    // A bit is 1 when at least one corresponding bit is 1.
    printf("a | b = %d\n", a | b);

    // Bitwise XOR (^)
    // A bit is 1 when the corresponding bits are different.
    printf("a ^ b = %d\n", a ^ b);

    // Bitwise NOT (~)
    // Flips every bit: 0 becomes 1 and 1 becomes 0.
    printf("~a = %d\n", ~a);

    // Left shift (<<)
    // Shifts bits to the left; for positive integers,
    // shifting left by one position generally multiplies by 2.
    printf("a << 1 = %d\n", a << 1);

    // Right shift (>>)
    // Shifts bits to the right; for positive integers,
    // shifting right by one position generally divides by 2.
    printf("a >> 1 = %d\n", a >> 1);

    return 0;
}
