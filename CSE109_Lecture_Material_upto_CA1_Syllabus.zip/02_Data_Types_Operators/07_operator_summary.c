#include <stdio.h>

int main() {
    /*
    C OPERATORS - QUICK SUMMARY

    1. Arithmetic:
       +  -  *  /  %

    2. Relational:
       ==  !=  <  >  <=  >=

    3. Logical:
       &&  ||  !

    4. Assignment:
       =  +=  -=  *=  /=  %=

    5. Bitwise:
       &  |  ^  ~  <<  >>

    6. Miscellaneous / Other:
       sizeof()     -> size in bytes
       ?:           -> conditional (ternary) operator
       ,            -> comma operator
       &            -> address-of operator
       *            -> dereference operator
       ()           -> function call
       .            -> structure member access
       ->           -> structure pointer member access
    */

    printf("See the comments above for the operator summary.\n");

    return 0;
}
