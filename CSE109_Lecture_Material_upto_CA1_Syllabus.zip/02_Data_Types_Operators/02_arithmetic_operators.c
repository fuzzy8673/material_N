#include <stdio.h>

int main() {
    int a = 8;
    int b = 4;

    // Arithmetic operators are used to perform mathematical operations.
    printf("a + b = %d\n", a + b);  // Addition
    printf("a - b = %d\n", a - b);  // Subtraction
    printf("a * b = %d\n", a * b);  // Multiplication
    printf("a / b = %d\n", a / b);  // Integer division
    printf("a %% b = %d\n", a % b); // Remainder (modulus)

    return 0;
}
