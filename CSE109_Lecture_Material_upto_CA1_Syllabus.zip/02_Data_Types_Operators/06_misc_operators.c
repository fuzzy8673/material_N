#include <stdio.h>

int add(int a, int b) {
    return a + b;
}

int main() {
    int a = 10;
    int b = 3;

    // sizeof()
    // Returns the size, in bytes, of a data type or variable.
    printf("Size of int: %zu bytes\n", sizeof(int));
    printf("Size of a: %zu bytes\n", sizeof(a));

    // Conditional (ternary) operator ?:
    // condition ? value_if_true : value_if_false
    int larger = (a > b) ? a : b;
    printf("Larger number: %d\n", larger);

    // Comma operator (,)
    // Evaluates expressions from left to right.
    // The value of the complete expression is the value of the last expression.
    int x, y;
    int result = (x = 5, y = 10, x + y);
    printf("Result using comma operator: %d\n", result);

    // Address-of operator (&)
    // Gives the memory address of a variable.
    printf("Address of a: %p\n", (void *)&a);

    // Pointer/dereference operator (*)
    // *ptr accesses the value stored at the address held by ptr.
    int *ptr = &a;
    printf("Value using *ptr: %d\n", *ptr);

    // Function call operator ()
    // Used to call a function.
    printf("add(10, 20) = %d\n", add(10, 20));

    // Important:
    // . and -> are also commonly treated as miscellaneous/member-access
    // operators in introductory C operator classifications.
    struct Student {
        int age;
    };

    struct Student s = {20};
    struct Student *p = &s;

    // . accesses a structure member through a structure variable.
    printf("s.age = %d\n", s.age);

    // -> accesses a structure member through a structure pointer.
    printf("p->age = %d\n", p->age);

    return 0;
}
