#include <stdio.h>

int main() {
    int a = 60;
    int b = 13;

    // += means: a = a + b
    a += b;
    printf("After a += b: %d\n", a);

    // -= means: a = a - b
    a -= b;
    printf("After a -= b: %d\n", a);

    // *= means: a = a * 2
    a *= 2;
    printf("After a *= 2: %d\n", a);

    // %= means: a = a % 10
    a %= 10;
    printf("After a %%= 10: %d\n", a);

    return 0;
}
