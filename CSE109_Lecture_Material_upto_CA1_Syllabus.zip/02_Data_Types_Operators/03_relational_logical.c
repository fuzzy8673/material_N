#include <stdio.h>

int main() {
    int a = 55;
    int b = 11;

    // Relational operators compare two values.
    // The result is 1 for true and 0 for false.
    printf("a == b : %d\n", a == b);  // Equal to
    printf("a != b : %d\n", a != b);  // Not equal to
    printf("a < b  : %d\n", a < b);   // Less than
    printf("a > b  : %d\n", a > b);   // Greater than

    // Logical AND (&&): true only when both conditions are true.
    printf("a > 0 && b > 0 : %d\n", a > 0 && b > 0);

    // Logical OR (||): true when at least one condition is true.
    printf("a > 100 || b > 0 : %d\n", a > 100 || b > 0);

    // Logical NOT (!): reverses a true/false result.
    printf("!(a == b) : %d\n", !(a == b));

    return 0;
}
