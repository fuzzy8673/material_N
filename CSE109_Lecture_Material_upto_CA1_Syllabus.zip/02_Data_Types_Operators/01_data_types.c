#include <stdio.h>

int main() {
    // Different variables store different types of data.
    int a = 7;           // Whole number
    float b = 7.4f;      // Decimal number, single precision
    double c = 7.2655;   // Decimal number, higher precision
    char ch = 'R';       // Single character

    // Print each value using its appropriate format specifier.
    printf("int: %d\n", a);
    printf("float: %.2f\n", b);
    printf("double: %.4lf\n", c);
    printf("char: %c\n", ch);

    // sizeof() returns the amount of memory occupied by a type.
    printf("Size of int: %zu bytes\n", sizeof(int));
    printf("Size of float: %zu bytes\n", sizeof(float));
    printf("Size of double: %zu bytes\n", sizeof(double));
    printf("Size of char: %zu byte\n", sizeof(char));

    return 0;
}
