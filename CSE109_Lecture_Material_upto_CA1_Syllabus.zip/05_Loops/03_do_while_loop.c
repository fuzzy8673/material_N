#include <stdio.h>

int main() {
    int choice;

    // do-while executes the body at least once.
    do {
        printf("\n1. Start");
        printf("\n2. Settings");
        printf("\n3. Exit");
        printf("\nEnter choice: ");
        scanf("%d", &choice);

        // The condition is checked after the loop body.
    } while (choice != 3);

    printf("Program ended.\n");

    return 0;
}
