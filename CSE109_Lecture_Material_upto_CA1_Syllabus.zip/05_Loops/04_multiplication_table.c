#include <stdio.h>

int main() {
    int n, i;

    // Take the number whose table we want to print.
    printf("Enter a number: ");
    scanf("%d", &n);

    // Repeat the multiplication from 1 to 10.
    for (i = 1; i <= 10; i++) {
        printf("%d x %d = %d\n", n, i, n * i);
    }

    return 0;
}
