#include <stdio.h>

int main() {
    int i = 10;

    // while checks the condition BEFORE executing the loop body.
    while (i >= 1) {
        printf("%d ", i);

        // Update the loop variable.
        // Without this, the loop could become infinite.
        i--;
    }

    return 0;
}
