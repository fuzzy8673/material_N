#include <stdio.h>

int main() {
    int i;

    // for loop has three parts:
    // initialization -> condition -> update
    for (i = 1; i <= 10; i++) {
        // This statement executes once during every iteration.
        printf("%d ", i);
    }

    return 0;
}
