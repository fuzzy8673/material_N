#include <stdio.h>

int main() {
    int password;

    // Ask for the password once before entering the loop.
    printf("Enter password: ");
    scanf("%d", &password);

    // Keep asking while the password is incorrect.
    while (password != 1234) {
        printf("Wrong password. Try again: ");
        scanf("%d", &password);
    }

    // This line is reached only when the correct password is entered.
    printf("Login successful.\n");

    return 0;
}
