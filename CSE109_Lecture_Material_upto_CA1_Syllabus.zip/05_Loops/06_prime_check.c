#include <stdio.h>

int main() {
    int n, i, isPrime = 1;

    // Take a number from the user.
    printf("Enter a number: ");
    scanf("%d", &n);

    // Numbers smaller than 2 are not prime.
    if (n < 2) {
        isPrime = 0;
    }

    // Check whether n is divisible by any number from 2 to n-1.
    for (i = 2; i < n && isPrime; i++) {
        if (n % i == 0) {
            // A divisor means the number is not prime.
            isPrime = 0;
        }
    }

    if (isPrime)
        printf("Prime\n");
    else
        printf("Not prime\n");

    return 0;
}
