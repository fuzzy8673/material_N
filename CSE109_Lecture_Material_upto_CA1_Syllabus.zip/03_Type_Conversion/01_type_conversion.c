#include <stdio.h>

int main() {
    int count = 5;
    float price = 2.50f;

    // Implicit conversion:
    // count is automatically converted from int to float before multiplication.
    float total = count * price;
    printf("Total: %.2f\n", total);

    // Character to integer:
    // A character can be converted to its ASCII integer value.
    char letter = 'A';
    int ascii_value = letter;
    printf("ASCII Value: %d\n", ascii_value);

    // Explicit conversion (casting):
    // (char) converts the integer 66 to the character represented by ASCII 66.
    int code = 66;
    char symbol = (char)code;
    printf("Character: %c\n", symbol);

    // Conversion from double to int:
    // The decimal/fractional part is removed.
    double pi = 3.14159;
    int cropped_pi = pi;
    printf("Cropped value: %d\n", cropped_pi);

    // Integer division normally removes the decimal part.
    // (float) forces the division to produce a floating-point result.
    int total_marks = 425;
    int subjects = 6;
    float average = (float)total_marks / subjects;
    printf("Average: %.2f\n", average);

    return 0;
}
