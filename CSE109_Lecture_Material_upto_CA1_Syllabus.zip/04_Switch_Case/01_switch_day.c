#include <stdio.h>

int main() {
    int day;

    // Take a number from 1 to 7.
    printf("Enter a number (1-7): ");
    scanf("%d", &day);

    // switch compares the expression with each case.
    switch (day) {
        case 1:
            printf("Monday\n");
            break;  // Exit switch after this case.

        case 2:
            printf("Tuesday\n");
            break;

        case 3:
            printf("Wednesday\n");
            break;

        case 4:
            printf("Thursday\n");
            break;

        case 5:
            printf("Friday\n");
            break;

        case 6:
            printf("Saturday\n");
            break;

        case 7:
            printf("Sunday\n");
            break;

        default:
            // Runs when no case matches.
            printf("Invalid day\n");
    }

    return 0;
}
