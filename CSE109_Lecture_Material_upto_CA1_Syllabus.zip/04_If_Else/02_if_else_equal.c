#include <stdio.h>

int main() {
    int num1, num2;

    // Take two integers as input.
    printf("Enter first number: ");
    scanf("%d", &num1);

    printf("Enter second number: ");
    scanf("%d", &num2);

    // == is the equality comparison operator.
    // It checks whether the two values are equal.
    if (num1 == num2) {
        printf("The two numbers are equal.\n");
    } else {
        printf("The two numbers are not equal.\n");
    }

    return 0;
}
