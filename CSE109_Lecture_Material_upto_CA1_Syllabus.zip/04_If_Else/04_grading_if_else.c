#include <stdio.h>

int main() {
    int score;

    // Take the student's score as input.
    printf("Enter score: ");
    scanf("%d", &score);

    // Conditions are checked from top to bottom.
    // The first true condition is executed.
    if (score >= 90) {
        printf("Grade: A\n");
    } else if (score >= 80) {
        printf("Grade: B\n");
    } else if (score >= 70) {
        printf("Grade: C\n");
    } else {
        // If none of the above conditions is true.
        printf("Grade: F\n");
    }

    return 0;
}
