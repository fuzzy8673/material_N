#include <stdio.h>

int main() {
    int num;

    // Take an integer from the user.
    printf("Enter a number: ");
    scanf("%d", &num);

    // If the remainder after division by 2 is 0, the number is even.
    if (num % 2 == 0) {
        printf("Even\n");
    } else {
        // Otherwise, the number is odd.
        printf("Odd\n");
    }

    return 0;
}
