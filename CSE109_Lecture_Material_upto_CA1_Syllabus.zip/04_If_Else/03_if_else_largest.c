#include <stdio.h>

int main() {
    int a, b;

    // Take two numbers from the user.
    printf("Enter two numbers: ");
    scanf("%d %d", &a, &b);

    // Check which number is greater.
    if (a > b) {
        printf("%d is greater.\n", a);
    } else if (b > a) {
        printf("%d is greater.\n", b);
    } else {
        // This executes when neither number is greater than the other.
        printf("Both numbers are equal.\n");
    }

    return 0;
}
