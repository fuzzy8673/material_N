#include <stdio.h>

int main() {
    int a, b, temp;

    // Take two numbers from the user.
    printf("Enter a: ");
    scanf("%d", &a);

    printf("Enter b: ");
    scanf("%d", &b);

    printf("Before swap: a = %d, b = %d\n", a, b);

    // Use a temporary variable to exchange the values.
    temp = a;
    a = b;
    b = temp;

    printf("After swap: a = %d, b = %d\n", a, b);

    return 0;
}
