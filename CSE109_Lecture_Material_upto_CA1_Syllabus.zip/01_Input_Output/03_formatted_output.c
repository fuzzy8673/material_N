#include <stdio.h>

int main() {
    float num = 3.523265;

    // %f uses the default floating-point precision.
    printf("Default value: %f\n", num);

    // %.2f prints exactly 2 digits after the decimal point.
    printf("2 digits after decimal: %.2f\n", num);

    // %.5f prints exactly 5 digits after the decimal point.
    printf("5 digits after decimal: %.5f\n", num);

    return 0;
}
