#include <stdio.h>

int main() {
    int num;
    float decimal;

    // Ask the user to enter an integer.
    printf("Enter an integer: ");
    scanf("%d", &num);   // %d reads an integer.

    // Ask the user to enter a decimal number.
    printf("Enter a decimal number: ");
    scanf("%f", &decimal);   // %f reads a float.

    // Print both values.
    // %.2f prints the float with exactly 2 digits after the decimal point.
    printf("You entered: %d and %.2f\n", num, decimal);

    return 0;   // Program completed successfully.
}
