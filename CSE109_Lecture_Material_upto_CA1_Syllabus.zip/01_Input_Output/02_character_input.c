#include <stdio.h>

int main() {
    char ch;

    // Ask the user to enter a character.
    printf("Enter a character: ");

    // %c is used to read a character.
    // The space before %c helps consume leftover whitespace/newline.
    scanf(" %c", &ch);

    // Print the character entered by the user.
    printf("You entered: %c\n", ch);

    return 0;
}
