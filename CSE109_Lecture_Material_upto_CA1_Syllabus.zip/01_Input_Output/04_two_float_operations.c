#include <stdio.h>

int main() {
    float a, b;

    // Take two decimal numbers from the user.
    printf("Enter the first number: ");
    scanf("%f", &a);

    printf("Enter the second number: ");
    scanf("%f", &b);

    // Perform arithmetic operations on the two numbers.
    printf("a + b = %.2f\n", a + b);  // Addition
    printf("a - b = %.2f\n", a - b);  // Subtraction
    printf("a * b = %.2f\n", a * b);  // Multiplication
    printf("a / b = %.2f\n", a / b);  // Division

    return 0;
}
