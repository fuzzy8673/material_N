CSE109 - Computer Programming
Student Lecture Material

This package contains clean, beginner-friendly C programs and practice problems.

Topics:
1. Input / Output
2. Data Types and Operators
3. Type Conversion
4. If-Else
5. Switch-Case
6. Loops: for, while, do-while
7. Jump Statements: break, continue, goto, return
8. Practice Problems

The code files contain explanatory comments near important statements and
operators so students can understand the logic while reading the code.

Recommended order:
Input/Output -> Data Types & Operators -> Type Conversion -> If-Else
-> Switch-Case -> Loops -> Jump Statements -> Practice Problems

Use the lecture PPT for the conceptual explanation and these files for
hands-on coding practice.
