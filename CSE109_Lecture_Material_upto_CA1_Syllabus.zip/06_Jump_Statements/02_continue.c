#include <stdio.h>

int main() {
    int i;

    // continue skips the remaining statements of the current iteration.
    for (i = 1; i <= 10; i++) {
        if (i == 5)
            continue;  // Skip printing 5.

        printf("%d ", i);
    }

    return 0;
}
