#include <stdio.h>

// This function adds two numbers and returns the result.
int add(int a, int b) {
    return a + b;  // Send the calculated value back to the caller.
}

int main() {
    // Call the add() function and store the returned value.
    int result = add(10, 20);

    printf("Result: %d\n", result);

    // return 0 indicates successful completion of main().
    return 0;
}
