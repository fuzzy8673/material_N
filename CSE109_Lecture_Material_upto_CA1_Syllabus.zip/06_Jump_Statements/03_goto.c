#include <stdio.h>

int main() {
    printf("Start\n");

    // goto transfers program control to a labeled statement.
    goto skip;

    // This statement is skipped because control jumps to 'skip'.
    printf("This will not print\n");

skip:
    printf("End\n");

    // Excessive use of goto can make programs difficult to understand,
    // debug, and maintain.

    return 0;
}
