#include <stdio.h>

/*
    TYPE 1: NO ARGUMENTS + NO RETURN VALUE
    ---------------------------------------
    The function does not receive any value from main()
    and does not return any value.

    void means: "this function does not return a value".
*/
void type1()
{
    printf("\nType 1: No arguments, No return value\n");

    // The function performs its task directly.
    printf("Hello from type 1 function.\n");
}

/*
    TYPE 2: ARGUMENTS + NO RETURN VALUE
    ------------------------------------
    The function receives two values but does not
    return a value.

    a and b are PARAMETERS.
*/
void type2(int a, int b)
{
    printf("\nType 2: Arguments, No return value\n");

    // Calculate and directly print the result.
    printf("Sum = %d\n", a + b);
}

/*
    TYPE 3: NO ARGUMENTS + RETURN VALUE
    ------------------------------------
    The function does not receive a value through
    parameters, but it returns a value to main().
*/
int type3()
{
    int n;

    printf("\nType 3: No arguments, Return value\n");

    // The function takes input by itself.
    printf("Enter a number: ");
    scanf("%d", &n);

    // Return the calculated value to the calling function.
    return n * n;
}

/*
    TYPE 4: ARGUMENTS + RETURN VALUE
    ---------------------------------
    The function receives values and also returns
    a result.

    This is one of the most commonly used function types.
*/
int type4(int a, int b)
{
    printf("\nType 4: Arguments, Return value\n");

    // Return the sum to main().
    return a + b;
}

int main()
{
    int result;

    /*
        TYPE 1 CALL

        No arguments are passed.
        Nothing is returned.
    */
    type1();

    /*
        TYPE 2 CALL

        10 and 20 are ARGUMENTS.
        The function does not return a value.
    */
    type2(10, 20);

    /*
        TYPE 3 CALL

        No arguments are passed.
        The function returns the square.
        We store the returned value in result.
    */
    result = type3();

    printf("Square = %d\n", result);

    /*
        TYPE 4 CALL

        30 and 40 are arguments.
        The function returns their sum.
    */
    result = type4(30, 40);

    printf("Sum = %d\n", result);

    return 0;
}

/*
    QUICK REVISION:

    Type 1:
        void type1()
        -> No arguments
        -> No return value

    Type 2:
        void type2(int a, int b)
        -> Arguments
        -> No return value

    Type 3:
        int type3()
        -> No arguments
        -> Returns a value

    Type 4:
        int type4(int a, int b)
        -> Arguments
        -> Returns a value
*/
