#include <stdio.h>

/*
    GLOBAL VARIABLE
    ----------------
    This variable is declared outside all functions.
    Therefore, it can be accessed by different functions
    in this program.
*/
int global = 100;

void demo()
{
    /*
        LOCAL VARIABLE
        --------------
        This variable is declared inside demo().
        It can be used only inside demo().
    */
    int local = 20;

    printf("Inside demo():\n");

    // global can be accessed here because it is a global variable.
    printf("Global = %d\n", global);

    // local belongs to demo(), so it can also be accessed here.
    printf("Local = %d\n", local);
}

int main()
{
    /*
        This is another LOCAL variable.
        It belongs only to main().
    */
    int local = 10;

    printf("Inside main():\n");

    // main() can access the global variable.
    printf("Global = %d\n", global);

    // This local variable belongs to main().
    printf("Local = %d\n\n", local);

    // Calling the demo() function.
    demo();

    return 0;
}

/*
    IMPORTANT:

    global:
        -> declared outside all functions
        -> can be accessed by multiple functions

    local:
        -> declared inside a function/block
        -> normally accessible only within that function/block

    Notice that main() and demo() can have local variables
    with the same name because they belong to different scopes.
*/
