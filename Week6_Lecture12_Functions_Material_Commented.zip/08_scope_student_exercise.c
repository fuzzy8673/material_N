#include <stdio.h>

/*
    GLOBAL VARIABLE
    ----------------
    This variable is declared outside all functions.
*/
int marks = 80;

void display()
{
    /*
        EXERCISE:
        Create a LOCAL variable named 'marks' with value 50.

        Then print marks.

        Think:
        Which marks will be printed?
        Global marks = 80
        Local marks  = 50
    */

    // Write your code here.
}

int main()
{
    /*
        EXERCISE:
        Create a LOCAL variable named 'marks' with value 90.

        Then:
        1. Print marks.
        2. Call display().
        3. Print marks again.
    */

    // Write your code here.

    return 0;
}

/*
    BEFORE RUNNING THE PROGRAM:

    Predict the output.

    Questions for students:
    1. What is the value of the global marks?
    2. What is the value of main()'s local marks?
    3. What is the value of display()'s local marks?
    4. Can display() directly access main()'s local marks?
    5. If local and global variables have the same name,
       which one gets priority?
*/
