WEEK 6 – LECTURE 12 – COMMENTED CODE MATERIAL

All C files are intentionally heavily commented so that:
1. You can use them while explaining in class.
2. Students can read the code independently.
3. Important concepts are explained beside the relevant lines.

FILES
-----
01_local_global_scope.c
    Basic local and global scope with comments.

02_same_name_local_global.c
    Demonstrates what happens when local and global variables
    have the same name.

03_four_function_types.c
    Demonstrates:
      - No arguments + No return value
      - Arguments + No return value
      - No arguments + Return value
      - Arguments + Return value

04_call_by_value_swap.c
    Demonstrates why normal swap does not modify the original
    variables.

05_pointer_based_swap.c
    Demonstrates address-based modification using pointers.
    This is commonly called "call by reference" in introductory C.

06_math_library_demo.c
    Demonstrates:
      sqrt(), pow(), abs(), ceil(), floor(), round(), trunc()

07_user_defined_math_menu.c
    Combines user-defined functions with math library functions.

08_scope_student_exercise.c
    Classroom exercise on local/global scope.

09_function_practice.c
    Practice skeleton for students.

COMPILATION
-----------
For normal C programs:
    gcc filename.c -o output

For the math library program:
    gcc 06_math_library_demo.c -o math_demo -lm

IMPORTANT C NOTE
----------------
C technically uses pass-by-value. It does not have C++-style reference
parameters. To modify the caller's variables, we pass their addresses
using pointers. Introductory C courses commonly call this "call by
reference".
