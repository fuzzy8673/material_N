#include <stdio.h>

/*
    PRACTICE 1
    ----------
    Write a function that accepts two integers and
    returns the larger number.

    Suggested function:
        int maximum(int a, int b)
*/


/*
    PRACTICE 2
    ----------
    Write a function that accepts an integer and
    returns 1 if it is even and 0 if it is odd.

    Suggested function:
        int isEven(int n)
*/


/*
    PRACTICE 3
    ----------
    Write a function to calculate factorial.

    Example:
        factorial(5) -> 120

    Suggested function:
        int factorial(int n)
*/


/*
    PRACTICE 4
    ----------
    Write a function to calculate the sum of digits.

    Example:
        sumDigits(1234) -> 10
*/


/*
    PRACTICE 5
    ----------
    Write a function to swap two numbers using pointers.

    Suggested function:
        void swap(int *a, int *b)
*/

int main()
{
    /*
        Write your function calls here to test
        the functions you create.
    */

    return 0;
}
