#include <stdio.h>

/*
    GLOBAL VARIABLE
    ----------------
    'number' is available throughout this source file.
*/
int number = 100;

void display()
{
    /*
        LOCAL VARIABLE
        --------------
        This local variable has the SAME NAME as the global
        variable.

        When a local and global variable have the same name,
        the local variable gets priority inside its scope.
    */
    int number = 50;

    // This prints the LOCAL number, which is 50.
    printf("Inside display(): %d\n", number);
}

int main()
{
    // Here, there is no local 'number', so the global variable is used.
    printf("Inside main(): %d\n", number);

    // Calling display().
    display();

    // We are back in main(), so the global number is used again.
    printf("Back in main(): %d\n", number);

    return 0;
}

/*
    OUTPUT:

    Inside main(): 100
    Inside display(): 50
    Back in main(): 100

    KEY IDEA:
    ----------
    A local variable takes priority over a global variable
    when both have the same name within the local variable's scope.
*/
