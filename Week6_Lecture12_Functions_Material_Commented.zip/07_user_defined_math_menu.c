#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
    USER-DEFINED FUNCTION
    ----------------------
    This function receives a decimal number and displays
    different rounding results.

    It uses standard math library functions internally.
*/
void showBasicMath(double n)
{
    printf("\nNumber = %.2f\n", n);

    // ceil() gives the smallest integer >= n.
    printf("ceil  = %.2f\n", ceil(n));

    // floor() gives the largest integer <= n.
    printf("floor = %.2f\n", floor(n));

    // round() gives the nearest integer.
    printf("round = %.2f\n", round(n));

    // trunc() removes the fractional part.
    printf("trunc = %.2f\n", trunc(n));
}

/*
    USER-DEFINED FUNCTION
    ----------------------
    Receives base and exponent.
    Uses the library function pow().
    Returns the calculated result.
*/
double calculatePower(double base, double exponent)
{
    return pow(base, exponent);
}

/*
    USER-DEFINED FUNCTION
    ----------------------
    Receives an integer and returns its absolute value.
*/
int calculateAbsolute(int n)
{
    return abs(n);
}

int main()
{
    double base, exponent;
    double number;
    int n;

    /*
        POWER CALCULATION
    */
    printf("Enter base and exponent: ");
    scanf("%lf %lf", &base, &exponent);

    /*
        Calling our own function.
        The function internally uses pow().
    */
    printf("Power = %.2f\n", calculatePower(base, exponent));

    /*
        ROUNDING FUNCTIONS
    */
    printf("\nEnter a decimal number: ");
    scanf("%lf", &number);

    // Call the user-defined function.
    showBasicMath(number);

    /*
        ABSOLUTE VALUE
    */
    printf("\nEnter an integer: ");
    scanf("%d", &n);

    printf("Absolute value = %d\n", calculateAbsolute(n));

    return 0;
}

/*
    THIS PROGRAM DEMONSTRATES:

    User-defined functions
            +
    Standard library functions

    User-defined:
        showBasicMath()
        calculatePower()
        calculateAbsolute()

    Library:
        pow()
        abs()
        ceil()
        floor()
        round()
        trunc()
*/
