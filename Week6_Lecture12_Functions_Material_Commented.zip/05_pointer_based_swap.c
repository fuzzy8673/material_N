#include <stdio.h>

/*
    ADDRESS-BASED MODIFICATION USING POINTERS
    ------------------------------------------
    Standard C passes arguments by value.

    To modify the original variables, we pass their
    ADDRESSES to the function.

    This is commonly called "call by reference" in
    introductory C courses.
*/
void swap(int *a, int *b)
{
    int temp;

    /*
        a contains the address of x.
        b contains the address of y.

        *a means:
        "the value stored at the address contained in a"

        *b means:
        "the value stored at the address contained in b"
    */

    // Store the value of x temporarily.
    temp = *a;

    // Put the value of y into x.
    *a = *b;

    // Put the old value of x into y.
    *b = temp;
}

int main()
{
    int x = 10;
    int y = 20;

    printf("Before function call: x = %d, y = %d\n", x, y);

    /*
        &x means "address of x".
        &y means "address of y".

        We pass addresses rather than just values.
    */
    swap(&x, &y);

    /*
        The function changed the values stored at
        the addresses of x and y.

        Therefore, the original variables are changed.
    */
    printf("After function call:  x = %d, y = %d\n", x, y);

    return 0;
}

/*
    IMPORTANT POINTER SYMBOLS:

    &x
       -> address of x

    *a
       -> value stored at the address held by a


    MEMORY IDEA:

        main()
        x = 10
        y = 20

          |       |
          |       |
         &x      &y
          |       |
          v       v
        swap(int *a, int *b)

    The function can access and modify the original
    variables using their addresses.
*/
