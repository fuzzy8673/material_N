#include <stdio.h>
#include <math.h>
#include <stdlib.h>

int main()
{
    double x = 5.7;
    double y = -5.7;

    double base = 2.0;
    double exponent = 3.0;

    /*
        sqrt()
        ------
        Finds the square root.

        sqrt(25) = 5
    */
    printf("sqrt(25)  = %.2f\n", sqrt(25.0));

    /*
        pow()
        -----
        Calculates base raised to a power.

        pow(2, 3) = 2^3 = 8
    */
    printf("pow(2,3)  = %.2f\n", pow(base, exponent));

    /*
        abs()
        -----
        Returns the absolute value of an INTEGER.

        abs(-10) = 10
    */
    printf("abs(-10)  = %d\n", abs(-10));

    /*
        ceil()
        -------
        Rounds UP toward the next integer.

        ceil(5.7) = 6.0
    */
    printf("ceil(5.7) = %.2f\n", ceil(x));

    /*
        floor()
        --------
        Rounds DOWN to the previous integer.

        floor(5.7) = 5.0
    */
    printf("floor(5.7)= %.2f\n", floor(x));

    /*
        round()
        --------
        Rounds to the nearest integer.

        round(5.7) = 6.0
    */
    printf("round(5.7)= %.2f\n", round(x));

    /*
        trunc()
        --------
        Removes the decimal/fractional part.

        trunc(5.7) = 5.0
    */
    printf("trunc(5.7)= %.2f\n", trunc(x));

    /*
        Let's see what happens with a negative number.
    */
    printf("\nFor a negative value:\n");

    printf("ceil(-5.7) = %.2f\n", ceil(y));
    printf("floor(-5.7)= %.2f\n", floor(y));
    printf("round(-5.7)= %.2f\n", round(y));
    printf("trunc(-5.7)= %.2f\n", trunc(y));

    return 0;
}

/*
    HEADER FILES:

    #include <math.h>
        Used for:
        sqrt(), pow(), ceil(), floor(), round(), trunc()

    #include <stdlib.h>
        Used for:
        abs()

    GCC compilation:
        gcc 06_math_library_demo.c -o math_demo -lm

    -lm tells GCC to link the math library when required.
*/
