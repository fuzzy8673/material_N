#include <stdio.h>

/*
    CALL BY VALUE
    -------------
    C passes a COPY of the value to the function.

    Therefore, changes made to 'a' and 'b' inside this
    function do NOT change the original x and y in main().
*/
void swap(int a, int b)
{
    int temp;

    /*
        a and b contain copies of x and y.

        Example:
        x = 10, y = 20

        After the function call:
        a = 10, b = 20
    */

    // Store the value of a temporarily.
    temp = a;

    // Put b's value into a.
    a = b;

    // Put the old a value into b.
    b = temp;

    // The copies have been swapped successfully.
    printf("Inside swap(): a = %d, b = %d\n", a, b);
}

int main()
{
    int x = 10;
    int y = 20;

    printf("Before function call: x = %d, y = %d\n", x, y);

    /*
        Passing x and y sends their VALUES to the function.

        swap receives:
        a = 10
        b = 20
    */
    swap(x, y);

    /*
        x and y are still unchanged.

        Why?
        Because swap() changed only the copies a and b.
    */
    printf("After function call:  x = %d, y = %d\n", x, y);

    return 0;
}

/*
    EXPECTED OUTPUT:

    Before function call: x = 10, y = 20
    Inside swap(): a = 20, b = 10
    After function call:  x = 10, y = 20

    IMPORTANT:
    ----------
    C uses pass-by-value.

    Original variable -> COPY -> Function

    Changing the copy does not change the original.
*/
