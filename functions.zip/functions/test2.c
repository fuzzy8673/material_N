#include<stdio.h>

// calc sum of 2 numbers - given by user
// return_data_type function_name(parameter1_data_type parameter1_name,parameter2_data_type parameter2_name,...){
//     // write the code as per your requirement

//     return value_of_return_data_type;
// }
// function defination
int calculateSum(int a,int b){   // int a -> parameter
    int sum=a+b;
    return sum;
}

void greet(){
    printf("Good morning all");
}





int main(){
    // int a,b;
    // printf("Enter 2 numbers: \n");
    // scanf("%d %d",&a,&b);
    // int result=calculateSum(a,b); // function calling  // a-> argument
    // printf("The sum is : %d\n",result);
    // greet();

   




    return 0;
}