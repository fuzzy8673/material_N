//write 4 functions:
    // int add(int a ,int b){
        //your code
    //}
    // sub()
    // multiply()
    // div()

// Each function will accept 2 integers as parameters
// at the end it should return the value
//in the main, take input of 2 numbers from the user

// call the functions and print the result;